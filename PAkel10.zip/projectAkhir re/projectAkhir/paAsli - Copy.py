import os
from prettytable import PrettyTable
import pwinput
import json
import datetime
os.system('cls')
ROOD_DIR = os.path.abspath(os.curdir)

# ini adalah prettytable untuk produk obat
produkjson = f"{ROOD_DIR}/projectAkhir/crudpa.json"
with open(produkjson, "r") as jsonproduk:
    data_produk = json.loads(jsonproduk.read())


# ini adalah prettytable untuk admin
tabelAdmin = PrettyTable()
tabelAdmin.field_names = ["nama admin", "password admin"]
adminjson = f"{ROOD_DIR}/projectAkhir/paloginadmin.json"
with open(adminjson, "r") as jsonadmin:
    data_admin = json.loads(jsonadmin.read())

for i in data_admin:
    tabelAdmin.add_row([i["username"], i["password"]])
# print(tabelAdmin)

# ini adalah prettytabel untuk pelanggan apotik
tabelPelanggan = PrettyTable()
tabelPelanggan.field_names = ["username", "password username", "saldo"]
pelangganjson = f"{ROOD_DIR}/projectAkhir/paloginpelanggan.json"
with open(pelangganjson, "r") as jsonpelanggan:
    data_pelanggan = json.loads(jsonpelanggan.read())

for i in data_pelanggan:
    tabelPelanggan.add_row([i["username"], i["password"], i["saldo"]])

# variabel saldo pelanggan
saldo_pelanggan = 0

# fungsi untuk menyimpan file json bagian data pelanggan
def savedatapelanggan():
    with open(pelangganjson, "w") as sn:
            json.dump(data_pelanggan, sn, indent=4)
# fungsi untuk menyipan file json bagian produk
def savejsonProduk():
    with open(produkjson, "w") as sn:
            json.dump(data_produk, sn, indent=4)

# fungsi untuk create produk
def create_produk():
    tambahId = int(input("tambahkan id baru: "))
    tambahObat = input("isi nama obatnya: ")
    tambahHarga = int(input("isi harganya: "))
    tambahStok = int(input("tambahkan stok: "))
    data_produk.append({"id":tambahId, "nama":tambahObat, "harga":tambahHarga, "stok":tambahStok})
    tabel_produk.add_row([tambahId, tambahObat, tambahHarga, tambahStok])
    savejsonProduk()


# fungsi read produk
def read_produk():
    global tabel_produk
    tabel_produk = PrettyTable()
    tabel_produk.field_names = ["ID", "Nama Obat", "Harga Obat", "Stok Obat"]
    for x in data_produk:
        tabel_produk.add_row([x["id"], x["nama"], x["harga"], x["stok"]])
    print(tabel_produk)

# fungsi update produk
def update_produk(id, nama=None, harga=None, stok=None):
    read_produk()
    print("Silahkan Update Daftar Obat")
    id = int(input("Masukkan ID Obat yang akan diperbarui: "))
    nama = str(input("Masukkan Nama Obat baru: "))
    harga = int(input("Masukkan Harga Obat baru: "))
    stok = int(input("Masukkan Stok Obat baru: "))
    for item in data_produk:
        if item["id"] == id:
            if nama:
                item["nama"] = nama
            if harga:
                item["harga"] = harga
            if stok:
                item["stok"] = stok
            savejsonProduk()
            return
    print("Produk tidak ditemukan")

# fungsi delete produk
def delete_produk(data_produk):
    hapusId = int(input("masukkan id obat yang akan dihapus: "))
    index = -1
    for i in range(0, len(data_produk)):
        id = data_produk[i]
        if hapusId == id["id"]:
            index = i
            break
    if index == -1:
        print("id obat tidak ditemukan")
    else:
        del data_produk[index]
        print("berhasil menghapus obat")
    savejsonProduk()

# fungsi untuk menu admin
def menuAdmin():
    while True:
        print(f'''
~~~~~~~| SELAMAT DATANG |~~~~~~~
~~~~~| Apotek SI'A Kel 10 |~~~~~
===============================
||     Menu Admin Apotek     ||
===============================
||    [1.] Lihat Produk      ||
||    [2.] Tambah Produk     ||
||    [3.] Update Produk     ||
||    [4.] Hapus Produk      ||
||    [0.] Keluar            ||
===============================''')
        pilihan = int(input("Masukkan pilihan Admin: "))
        if pilihan == 1:
            os.system('cls')
            read_produk()
        elif pilihan == 2:
            os.system('cls')
            read_produk()
            create_produk()
        elif pilihan == 3:
            os.system('cls')
            update_produk(id, nama=None, harga=None, stok=None)
        elif pilihan == 4:
            os.system('cls')
            read_produk()
            delete_produk(data_produk)
        elif pilihan == 0:
            os.system('cls')
            break
        else:
            print("masukkan angka dengan benar")


# fungsi melihat list admin
def liatAdmin():
    print(tabelAdmin)

# fungsi untuk menambah admin/registrasi
def regis():
    print("Silahkan Registrasi Akun Anda^^")
    username = input("Masukkan nama admin baru: ")
    password = pwinput.pwinput("Masukkan password admin baru: ")
    for i in data_admin:
        if username == i["username"]:
            print("username sudah tersedia, cari username yang lain!")
            break
    data_admin.append({"username": username, "password": password})
    tabelAdmin.add_row([username, password])
    with open(adminjson, "w") as sn:
        json.dump(data_admin, sn, indent=4)
    print(f"Admin {username} berhasil ditambahkan.")
    print(tabelAdmin)

# fungsi buat login admin
def login_admin():
    admin_regis = input("Apakah Sudah Memiliki Akun? y/t: ")
    if admin_regis == "y":
        print("~~~~~~~~~~~~~~Silahkan Login~~~~~~~~~~~~~~~~")
        print("Masukkan Username dan Password dengan Benar!")
        username = input("Masukkan username: ")
        pw = pwinput.pwinput("Masukkan password: ")
        for i in data_admin:
            if i["username"] == username:
                if i["password"] == pw:
                    print("Login Berhasil.")
                    print(f"Hallo Admin: {username}")
                    menuAdmin()
                else:
                    print("password atau username anda masukkan salah")
        else:
            print("password atau username anda tidak terdaftar")
    elif admin_regis == "t":
        while True:
            buatadmin = input("Apakah Ingin Membuat Akun Admin? y/t: ")
            if buatadmin == "y":
                regis()
            elif buatadmin == "t":
                break
            else:
                print("Pilihan Anda Tidak Valid")

#fungsi login pelanggan
def loginpelanggan():
    global saldo_pelanggan
    global inUsername
    print("Selamat Datang Di Apotek SI'A Kel 10")
    pilihMember = input("apakah sudah memiliki akun pelanggan? y/t: ")
    if pilihMember == "y":
        inUsername = input("masukkan username anda: ")
        inpass = pwinput.pwinput("masukkan password anda: ")
        for x in data_pelanggan:
            if x ["username"] == inUsername:
                for y in data_pelanggan:
                    if y ["password"] == inpass:
                        saldo_pelanggan = x["saldo"]
                        print("Login Berhasil.")
                        print(f"Hallo Pelanggan: {inUsername}")
                        menu_pelanggan()
                        return True
        print("username atau password salah atau tidak terdaftar")
    elif pilihMember == "t":
        while True:
            buatTidak = input("apakah anda ingin membuat akun pelanggan? y/t: ")
            if buatTidak == "y":
                tambah_pelanggan()
            elif buatTidak == "t":
                print("Silahkan buat akun terlebih dulu.")
            else:
                break
        print("username atau password salah atau tidak terdaftar")
    else:
        print("pilihan anda tidak valid")
        
# fungsi untuk menambah pelanggan
def tambah_pelanggan():
    username = input("Masukkan nama pelanggan baru: ")
    password = pwinput.pwinput("Masukkan password pelanggan baru: ")
    saldo = int(input("berapa saldo anda: "))
    data_pelanggan.append({"username": username, "password": password, "saldo": saldo})
    tabelPelanggan.add_row([username, password, saldo])
    with open(pelangganjson, "w") as sn:
        json.dump(data_pelanggan, sn, indent=4)
    print(f"Pelanggan baru {username} berhasil ditambahkan.")
    print(tabelPelanggan)

# # fungsi untuk menghapus akun pelanggan (kalo mau pake)
# def hapus_pelanggan(data_pelanggan):
#     hapusAkun = input("masukkan username akun yang ingin dihapus: ")
#     index =  -1
#     for i in range(0, len(data_pelanggan)):
#         username = data_pelanggan[i]
#         if hapusAkun == username["username"]:
#             index = i

#     if index == -1:
#         print("username tidak ditemukan")
#     else:
#         del data_pelanggan[index]
#         print("berhasil menghapus akun")
#     with open(pelangganjson, "w") as sn:
#         json.dump(data_pelanggan, sn, indent=4)


# fungsi untuk pembeli membeli obat dan dapat langsung mencetak struk
def belanja():
    global saldo_pelanggan
    produk_dict = {produk["id"]: produk for produk in data_produk}
    read_produk()
    pilih = int(input("Masukkan id obat: "))
    if pilih in produk_dict:
        produk_terpilih = produk_dict[pilih]
        print(f"Produk yang anda pilih adalah {produk_terpilih['nama']}")
        kuantitas = int(input("Masukkan kuantitas barang: "))
        if kuantitas <= produk_terpilih["stok"]:
            harga_total = produk_terpilih["harga"] * kuantitas 
            if saldo_pelanggan >= harga_total:
                sisa_saldo = saldo_pelanggan - harga_total
                saldo_pelanggan = sisa_saldo
                for pelanggan in data_pelanggan:
                    if pelanggan["username"] == inUsername:
                        pelanggan["saldo"] = saldo_pelanggan
                        savedatapelanggan()
                print("Barang berhasil dipilih")
                cetakstruk = input("Cetak Struk Belanja Anda? y/n: ")
                if cetakstruk == "y":
                    os.system('cls')
                    print("\n")
                    print("*" * 80)
                    print("                  APOTEK SI'A KEL 10                ")
                    print("*" * 80)
                    for pelanggan in data_pelanggan:
                        if pelanggan["username"] == inUsername:
                            print(f"Tanggal Transaksi: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                            print(f"Nama Pelanggan: {inUsername}")
                            tabelstruk = PrettyTable(["ID Obat", "Nama Obat", "Kuantitas", "Harga Satuan", "Total Harga"])
                            tabelstruk.add_row([pilih,produk_terpilih['nama'], kuantitas, produk_terpilih['harga'], harga_total])
                            print(tabelstruk)
                            bayar = input("Apakah Anda Akan Membayar? y/t: ")
                            if bayar == "y":
                                print(f"Saldo Anda Sebelum Transaksi: {saldo_pelanggan + harga_total}")
                                print(f"Saldo Anda Setelah Transaksi: {saldo_pelanggan}")
                                print("Terimakasih Telah Melakukan Transaksi!")
                                print("       !Semoga Lekas Sembuh!          ")
                            elif bayar == "t":
                                print("Terimakasi Telah Mencoba Cekout")
                                break
                            else:
                                print("Pilihan Anda Tidak Valid!")
                elif cetakstruk == "n":
                    print("Terimakasih sudah menggunakan program")
                else:
                    print("Pilihan anda tidak valid")
            else:
                print("Saldo tidak cukup")
        else:
            print("Kuantitas yang anda pesan melebihi stok")
    else:
        print("Barang tidak ada")


# fungsi menu pelanggan
def menu_pelanggan():
    global saldo_pelanggan
    while True:
        print(f'''
~~~~~~~~~~~| SELAMAT DATANG |~~~~~~~~~~
~~~~~~~~~| Apotek SI'A Kel 10 |~~~~~~~~
========================================
||        Menu Pembeli Apotek         ||
========================================
||    [1.] Lihat dan beli Produk      ||
||    [2.] Isi Saldo                  ||
||    [3.] Tampilkan Saldo            ||
||    [0.] Keluar                     ||
========================================''')
        pilih = int(input("pilih menu: "))
        if pilih == 1:
            os.system('cls')
            print("~" * 50)
            print("                 SELAMAT BERBELANJA!             ")
            print("~" * 50)
            belanja()
        elif pilih == 2:
            os.system('cls')
            print("~" * 50)
            print("                   SELAMAT DATANG                 ")
            print("                   ISI SALDO ANDA                 ")
            print("~" * 50)
            tambah_saldo = int(input("Masukkan berapa saldo yang ingin tambah: "))
            saldo_baru = saldo_pelanggan + tambah_saldo
            saldo_pelanggan = saldo_baru
            for pelanggan in data_pelanggan:
                if pelanggan["username"] == inUsername:
                    pelanggan["saldo"] = saldo_pelanggan
                    savedatapelanggan()
                    print("Saldo Anda Berhasil Di Tambahkan!")
        elif pilih == 3:
            os.system('cls')
            print("Login Berhasil.")
            print(f"Hallo Admin: {inUsername}")
            print(f"Saldo anda sekarang: {saldo_pelanggan}")
        elif pilih == 0:
            os.system('cls')
            break

# fungsi program utama
def main():
    while True:
        print(f'''
~~~~~~~~~~~| SELAMAT DATANG |~~~~~~~~~~
~~~~~~~~~| Apotek SI'A Kel 10 |~~~~~~~~
========================================
||           Masuk Sebagai            ||
========================================
||    [1.] Admin                      ||
||    [2.] Pembeli                    ||
||    [0.] Keluar                     ||
========================================''')
        pilihan = int(input("Masuk Sebagai: "))
        if pilihan == 1:
            os.system('cls')
            login_admin()
        elif pilihan == 2:
            os.system('cls')
            loginpelanggan()
        elif pilihan == 0:
            os.system('cls')
            print("Terimakasih Telah Mengguanakan Program ini ^^ ! ")
            print(f'''
====================================
SEMANGAT BEKERJA DAN JAGA KESEHATAN!
====================================''')
            break
        else:
            print("pilihan anda tidak valid")
main()

